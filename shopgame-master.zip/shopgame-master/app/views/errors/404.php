<?php
require_once ROOT_PATH . '/app/views/partials/header.php';
?>

<div class="container">
    <div class="row mt-4">
        <div class="col-sm-12">
            <div class="text-center">
                <h2>404 not found</h2>
                <p>Không tìm thấy trang bạn đang tìm kiếm!</p>
            </div>
        </div>
    </div>
</div>

<?php
require_once ROOT_PATH . '/app/views/partials/footer.php';
?>